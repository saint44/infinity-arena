#!/usr/bin/env bash
# enable_env_autoload.sh
# Usage: run this *inside* your honey_merged_mesh_superpack folder to back up and replace Makefile.
set -euo pipefail
TARGET="Makefile"
BACKUP="Makefile.backup.$(date +%Y%m%d%H%M%S)"
echo "Backing up ${TARGET} -> ${BACKUP}"
cp -f "${TARGET}" "${BACKUP}" || true
echo "Placing env-aware Makefile"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp -f "${SCRIPT_DIR}/Makefile" "./Makefile"
echo "Done. Run:  make up